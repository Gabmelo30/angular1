import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Produto, produtoservice} from 'produto.service';

@Component({
  selector: 'app-tabela-produto',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './tabela-produto.component.html',
  styleUrl: './tabela-produto.component.css'
})
export class TabelaProdutoComponent {
 produto: Produto[] = [];

 constructor(private produtoService: ProdutoService) {}

 ngOnInit() {
  this.produto = this.produtoService.obterProdutos();
 }
}
